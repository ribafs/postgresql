---------------------------------------------------------------------------
--
--	Cria um database exemplo de uma empresa com diversos departamentos, 
--      usuarios, grupos, esquemas e permiss�es de acesso diferenciadas 
--      aos esquemas
--	
--	Autor  : Luiz Gonzaga da Mata			Versao 1.0
--	
--	Email  : gonzaga@pbh.gov.br
--	   
--	Data   : 23/09/2004				
--
--
--	Garantia : N�o h� garantia nenhuma sobre a utilizacao deste exemplo
--                 de utiliza��o de esquemas e permiss�es.
-- 
--	E de inteira responsabilidade do usuario a utilizacao deste.
--
---------------------------------------------------------------------------



--
-- PostgreSQL database dump
--
SET client_encoding = 'LATIN1';

-- Cria o usuario propriet�rio do database empresa_exemplo

SET SESSION AUTHORIZATION 'postgres';

CREATE USER empresa -- propriet�rio do database
  ENCRYPTED PASSWORD ''
  CREATEDB CREATEUSER;
  

-- Cria o database empresa_exemplo com o propriet�rio empresa


CREATE DATABASE empresa_exemplo
  WITH OWNER = empresa
       ENCODING = 'LATIN1';



-- Cria�ao de grupos de usu�rios

CREATE Group grava_adm;

CREATE Group grava_finan;

CREATE Group grava_prod;

CREATE Group grava_vend;

CREATE Group le_adm;

CREATE Group le_finan;

CREATE Group le_prod;

CREATE Group le_vend;


-- atribui o user empresa a todos os grupos poderosos

ALTER GROUP grava_adm ADD USER empresa;
ALTER GROUP grava_finan ADD USER empresa;
ALTER GROUP grava_prod ADD USER empresa;
ALTER GROUP grava_vend ADD USER empresa;


-- cria��o de usu�rios do database

CREATE USER administrativo
  ENCRYPTED PASSWORD ''
  NOCREATEDB NOCREATEUSER;
ALTER GROUP grava_adm ADD USER administrativo;
ALTER GROUP le_finan ADD USER administrativo;
ALTER GROUP le_prod ADD USER administrativo;
ALTER GROUP le_vend ADD USER administrativo;


CREATE USER financeiro
  ENCRYPTED PASSWORD ''
  NOCREATEDB NOCREATEUSER;
ALTER GROUP grava_finan ADD USER financeiro;
ALTER GROUP grava_vend ADD USER financeiro;
ALTER GROUP le_adm ADD USER financeiro;

CREATE USER producao
  ENCRYPTED PASSWORD ''
  NOCREATEDB NOCREATEUSER;
ALTER GROUP grava_prod ADD USER producao;
ALTER GROUP grava_vend ADD USER producao;
ALTER GROUP le_adm ADD USER producao;

CREATE USER vendas
  ENCRYPTED PASSWORD ''
  NOCREATEDB NOCREATEUSER;
ALTER GROUP grava_finan ADD USER vendas;
ALTER GROUP grava_prod ADD USER vendas;
ALTER GROUP grava_vend ADD USER vendas;
ALTER GROUP le_adm ADD USER vendas;

-- Cria��o dos esquemas

CREATE SCHEMA administrativo AUTHORIZATION administrativo;
CREATE SCHEMA financeiro AUTHORIZATION financeiro;
CREATE SCHEMA producao AUTHORIZATION producao;
CREATE SCHEMA vendas AUTHORIZATION vendas;


-- atribui a permiss�o de uso aos esquemas

GRANT USAGE ON SCHEMA "administrativo" TO "financeiro", "producao", "vendas";

GRANT USAGE ON SCHEMA "financeiro" TO "administrativo", "producao", "vendas";

GRANT USAGE ON SCHEMA "producao" TO  "administrativo", "financeiro", "vendas";

GRANT USAGE ON SCHEMA "vendas" TO "administrativo", "financeiro", "producao";

-- Seta a permiss�o para o propri�tario do database

SET SESSION AUTHORIZATION 'empresa';

-- Seta o esquema producao onde ser�o criadas as tabelas

SET search_path = producao, pg_catalog;


CREATE TABLE prod01 (
    a integer NOT NULL,
    b integer
);

-- Aplica as permiss�es aos grupos para a tabela prod01

REVOKE ALL ON TABLE prod01 FROM PUBLIC;
GRANT ALL ON TABLE prod01 TO GROUP grava_prod;
GRANT SELECT ON TABLE prod01 TO GROUP le_prod;

CREATE TABLE prod02 (
    a integer NOT NULL,
    b integer
);

-- Aplica as permiss�es aos grupos para a tabela prod02

REVOKE ALL ON TABLE prod02 FROM PUBLIC;
GRANT ALL ON TABLE prod02 TO GROUP grava_prod;
GRANT SELECT ON TABLE prod02 TO GROUP le_prod;

-- Seta o esquema administrativo onde ser�o criadas as tabelas

SET search_path = administrativo, pg_catalog;


CREATE TABLE adm01 (
    a integer NOT NULL,
    b integer
);

-- Aplica as permiss�es aos grupos para a tabela adm01

REVOKE ALL ON TABLE adm01 FROM PUBLIC;
GRANT ALL ON TABLE adm01 TO GROUP grava_adm;
GRANT SELECT ON TABLE adm01 TO GROUP le_adm;


CREATE TABLE adm02 (
    a integer NOT NULL,
    b integer
);


-- Aplica as permiss�es aos grupos para a tabela adm02

REVOKE ALL ON TABLE adm02 FROM PUBLIC;
GRANT ALL ON TABLE adm02 TO GROUP grava_adm;
GRANT SELECT ON TABLE adm02 TO GROUP le_adm;


-- Seta o esquema financeiro onde ser�o criadas as tabelas

SET search_path = financeiro, pg_catalog;


CREATE TABLE finan01 (
    a integer NOT NULL,
    b integer
);

-- Aplica as permiss�es aos grupos para a tabela finan01

REVOKE ALL ON TABLE finan01 FROM PUBLIC;
GRANT ALL ON TABLE finan01 TO GROUP grava_finan;
GRANT SELECT ON TABLE finan01 TO GROUP le_finan;

CREATE TABLE finan02 (
    a integer NOT NULL,
    b integer
);

-- Aplica as permiss�es aos grupos para a tabela finan02

REVOKE ALL ON TABLE finan02 FROM PUBLIC;
GRANT ALL ON TABLE finan02 TO GROUP grava_finan;
GRANT SELECT ON TABLE finan02 TO GROUP le_finan;

-- Seta o esquema vendas onde ser�o criadas as tabelas

SET search_path = vendas, pg_catalog;

CREATE TABLE vend01 (
    a integer NOT NULL,
    b integer
);

-- Aplica as permiss�es aos grupos para a tabela vend01

REVOKE ALL ON TABLE vend01 FROM PUBLIC;
GRANT ALL ON TABLE vend01 TO GROUP grava_vend;
GRANT SELECT ON TABLE vend01 TO GROUP le_vend;

CREATE TABLE vend02 (
    a integer NOT NULL,
    b integer
);

-- Aplica as permiss�es aos grupos para a tabela vend02

REVOKE ALL ON TABLE vend02 FROM PUBLIC;
GRANT ALL ON TABLE vend02 TO GROUP grava_vend;
GRANT SELECT ON TABLE vend02 TO GROUP le_vend;

SET SESSION AUTHORIZATION 'postgres';

--
-- TOC entry 3 (OID 2200)
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'Standard public schema';


