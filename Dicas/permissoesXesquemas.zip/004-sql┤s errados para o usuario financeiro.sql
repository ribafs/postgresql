---------------------------------------------------------------------------
--
--	Exemplo de sql�s errados de acordo com a permiss�o para o usuario 
--      financeiro
--      
--	
--	Autor  : Luiz Gonzaga da Mata			Versao 1.0
--	
--	Email  : gonzaga@pbh.gov.br
--	   
--	Data   : 23/09/2004				
--
--
--	Garantia : N�o h� garantia nenhuma sobre a utilizacao deste exemplo
--                 de utiliza��o de esquemas e permiss�es.
-- 
--	E de inteira responsabilidade do usuario a utilizacao deste.
--
---------------------------------------------------------------------------

-- Seta a sess�o para o usu�rio financeiro

SET SESSION AUTHORIZATION 'financeiro';

-- Seta o esquema producao onde n�o podem ser consultadas as tabelas

SET search_path = producao, pg_catalog;

select * from prod01;
select * from prod02;





