---------------------------------------------------------------------------
--
--	Exemplo de sql�s errados de acordo com a permiss�o para o usuario 
--      administrativo
--      
--	
--	Autor  : Luiz Gonzaga da Mata			Versao 1.0
--	
--	Email  : gonzaga@pbh.gov.br
--	   
--	Data   : 23/09/2004				
--
--
--	Garantia : N�o h� garantia nenhuma sobre a utilizacao deste exemplo
--                 de utiliza��o de esquemas e permiss�es.
-- 
--	E de inteira responsabilidade do usuario a utilizacao deste.
--
---------------------------------------------------------------------------


-- Seta a sess�o para o usuario administrativo

SET SESSION AUTHORIZATION 'administrativo';

-- Seta o esquema financeiro onde, somente, podem ser consultadas as tabelas

SET search_path = financeiro, pg_catalog;

insert into finan01 values(1,1);
insert into finan02 values(1,1);


-- Seta o esquema producao onde, somente, podem ser consultadas as tabelas

SET search_path = producao, pg_catalog;

insert into prod01 values(1,1);
insert into prod02 values(1,1);

-- Seta o esquema vendas onde, somente, podem ser consultadas as tabelas

SET search_path = vendas, pg_catalog;

insert into vend01 values(1,1);
insert into vend02 values(1,1);



