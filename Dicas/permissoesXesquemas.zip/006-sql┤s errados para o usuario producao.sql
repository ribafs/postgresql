---------------------------------------------------------------------------
--
--	Exemplo de sql�s errados de acordo com a permiss�o para o usuario
--      producao
--      
--	
--	Autor  : Luiz Gonzaga da Mata			Versao 1.0
--	
--	Email  : gonzaga@pbh.gov.br
--	   
--	Data   : 23/09/2004				
--
--
--	Garantia : N�o h� garantia nenhuma sobre a utilizacao deste exemplo
--                 de utiliza��o de esquemas e permiss�es.
-- 
--	E de inteira responsabilidade do usuario a utilizacao deste.
--
---------------------------------------------------------------------------



-- Seta a sess�o para o usu�rio producao

SET SESSION AUTHORIZATION 'producao';

-- -- Seta o esquema financeiro onde n�o podem ser inseridas tuplas nas tabelas

SET search_path = financeiro, pg_catalog;

insert into finan01 values(1,1);
insert into finan02 values(1,1);

-- Seta o esquema administrativo onde n�o podem ser inseridas tuplas nas tabelas

SET search_path = administrativo, pg_catalog;

insert into adm01 values(1,1);
insert into adm02 values(1,1);





