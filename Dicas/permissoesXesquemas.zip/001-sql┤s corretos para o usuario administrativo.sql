---------------------------------------------------------------------------
--
--	Exemplo de sql�s corretos de acordo com a permiss�o para o usuario
--      administrativo 
--      
--	
--	Autor  : Luiz Gonzaga da Mata			Versao 1.0
--	
--	Email  : gonzaga@pbh.gov.br
--	   
--	Data   : 23/09/2004				
--
--
--	Garantia : N�o h� garantia nenhuma sobre a utilizacao deste exemplo
--                 de utiliza��o de esquemas e permiss�es.
-- 
--	E de inteira responsabilidade do usuario a utilizacao deste.
--
---------------------------------------------------------------------------





-- Seta a sess�o para o usu�rio administrativo

SET SESSION AUTHORIZATION 'administrativo';

-- Seta o esquema administrativo onde ser�o inseridas tuplas nas tabelas

SET search_path = administrativo, pg_catalog;

insert into adm01 values(1,1);
insert into adm02 values(1,1);

-- Seta o esquema financeiro onde, somente, podem ser consultadas as tabelas

SET search_path = financeiro, pg_catalog;

select * from finan01;
select * from finan02;

-- Seta o esquema producao onde, somente, podem ser consultadas as tabelas

SET search_path = producao, pg_catalog;

select * from prod01;
select * from prod02;

-- Seta o esquema vendas onde, somente, podem ser consultadas as tabelas

SET search_path = vendas, pg_catalog;

select * from vend01;
select * from vend02;



