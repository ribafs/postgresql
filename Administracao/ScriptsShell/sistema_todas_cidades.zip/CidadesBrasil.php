<?php
//
// +----------------------------------------------------------------------+
// | Este script pode ser modificado livremente, desde que os cr�ditos    |
// | sejam mantidos.                                                      |
// +----------------------------------------------------------------------+
// | Author: Silvano Girardi Jr. <sgj@dr.com>                             |
// +----------------------------------------------------------------------+

/**
 * Esta classe utiliza as tabelas contendo os dados de todas as cidades do Brasil
 *
 * @version     1.0
 */
class CidadesBrasil {
    
    /**
     * Retorna o resultado da consulta pelos estados
     *
     * @return      resource    $retorno    o resultado da consulta
     */
    function listarEstados()
    {
        return @mysql_query("SELECT * FROM dados_estados ORDER BY nome ASC");
    }
    
    /**
     * Retorna o resultado da consulta pelas cidades de um determinado estado.
     *
     * @param       int         $id_estado  id do estado que se deseja a listagem das cidades
     * @return      resource    $retorno    o resultado da consulta
     */
    function listarCidades($id_estado)
    {
        return @mysql_query("SELECT * FROM dados_cidades WHERE id_estado='$id_estado' ORDER BY nome ASC");
    }
    
    /**
     * Retorna o select dos estados, para que possa ser utilizado no html.
     *
     * @return      string  $retorno        o select pronto para ser usado
     */
    function retornaSelectEstados()
    {
        $retorno = "<select name=\"id_estado\" onChange=\"buscaCidades(this)\">\n<option value=''>Selecione um estado</option>\n"; 
        $estados = CidadesBrasil::listarEstados();
        while ($dados_estados = mysql_fetch_assoc($estados)) {
            $retorno .= "<option value=\"".$dados_estados['id']."\">".$dados_estados['nome']."</option>\n";
        }
        $retorno .= "</select>\n";
        
        return $retorno;
    }
    
    /**
     * Retorna o select das cidades, sem quebras de linha, para que possa ser utilizado
     * no JavaScript.
     *
     * @param       int     $id_estado      id do estado que se deseja a lista das cidades
     * @return      string  $retorno        o select pronto para ser usado
     */
    function retornaSelectCidades($id_estado)
    {
        $retorno = "<select name='id_cidade'><option value=''>Selecione uma cidade</option>"; 
        $cidades = CidadesBrasil::listarCidades($id_estado);
        while ($dados_cidades = mysql_fetch_assoc($cidades)) {
            $retorno .= "<option value='".$dados_cidades['id']."'>".$dados_cidades['nome']."</option>";
        }
        $retorno .= "</select>";
        
        return $retorno;
    }
}

?>