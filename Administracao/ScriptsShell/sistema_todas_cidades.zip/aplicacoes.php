<?php
$bd_host    = "localhost";
$bd_usuario = "root";
$bd_senha   = "root";
$bd_banco   = "cidades_brasil";

$bd_conexao = mysql_connect($bd_host, $bd_usuario, $bd_senha);
mysql_select_db($bd_banco);

require_once "CidadesBrasil.php";
?>