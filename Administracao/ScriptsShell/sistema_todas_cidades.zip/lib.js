function buscaCidades(campo)
{
    eval("parent.escondido.location='escondido.php?id_estado="+campo.options[campo.selectedIndex].value+"'");
}

function carregaCidades()
{ 
    var novo_select;
    var nome_div = "cidades";
    novo_select  = parent.escondido.retornaCidades();
    
    if (document.getElementById) {
        document.getElementById(nome_div).innerHTML = novo_select;
    } else if (document.all) {
        document.all[nome_div].innerHTML = novo_select;
    } else if(document.layers) {
        document[nome_div].innerHTML = novo_select;
    }
}