<?php
require_once "aplicacoes.php";
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Todas as Cidades do Brasil</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<script language="JavaScript" src="lib.js"></script>
</head>

<body bgcolor="#F4F4F4">
<iframe src="escondido.php" name="escondido" width="0" height="0"></iframe>
<div id="estados"><?=CidadesBrasil::retornaSelectEstados()?></div>
<div id="cidades"></div>
</body>
</html>
