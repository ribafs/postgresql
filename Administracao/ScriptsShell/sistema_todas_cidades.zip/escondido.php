<?php
require_once "aplicacoes.php";
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Todas as Cidades do Brasil</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<script language="JavaScript">
<!--
function retornaCidades()
{
    return "<?php
if (isset($id_estado) && !empty($id_estado)) {
    echo CidadesBrasil::retornaSelectCidades($id_estado);
}
?>";
}
//-->
</script>
</head>

<body onLoad="parent.carregaCidades()">

</body>
</html>