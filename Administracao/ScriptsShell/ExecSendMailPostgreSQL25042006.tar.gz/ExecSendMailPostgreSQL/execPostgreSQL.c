/*25/10/2005 By Otacilio de Araujo Ramos Neto 
  otacilio_neto@yahoo.com.br*/
/*Licenca:
  Voce pode fazer o que quiser com este software, exceto
  Remover esta licenca,
  dizer de qualquer forma que nao foi Otacilio de Araujo Ramos Neto que 
  escreveu este software.
  Se voce utilizar ou distribuir este software voce automaticamente esta 
  concordando com os termos desta licenca.
  
  Este software eh distribuido acreditando-se que ele eh totalmente funcional,
  mas sem nenhuma garantia implicita ou explicita disto, qualquer dano de 
  qualquer tipo deve ser assumido pelo usuario deste software. 
 */

#include "postgres.h"
#include <string.h>
#include "fmgr.h"

#include <sys/types.h>
#include <unistd.h>
#include <sys/wait.h>

#include <sys/time.h>
#include <sys/resource.h>
#include <stdlib.h>

#include <syslog.h>
#include <stdarg.h>

extern char **environ;

int erro;

PG_FUNCTION_INFO_V1(exec1);

Datum exec1(PG_FUNCTION_ARGS){

	pid_t child; /*Pid do processo filho criado*/
	int status;  /*status de terminacao do processo filho*/
	
	/*Argumentos passados a funcao*/

	text	*param0 = PG_GETARG_TEXT_P(0);	

	/*Variaveis das strings de comando*/
	
	char *args[2];

	erro = 0;
	
	/*+1 para o caracter de nulo*/
	args[0] = (char *) palloc(VARSIZE(param0)+1-VARHDRSZ);
	memcpy(args[0],VARDATA(param0),VARSIZE(param0)-VARHDRSZ);
	
	args[0][VARSIZE(param0)-VARHDRSZ]='\0';
	args[1]=NULL;
		
	/*Fork em um novo processo*/
	if(!(child=vfork())){
		/*O processo filho entra aqui*/
		
		/*Substitui a imagem de memoria do processo*/
		syslog(LOG_INFO,"PostgreSQL executando o comando %s\n",args[0]);
		if(execve(args[0],args,environ)==-1){
			/*Nao foi possivel substituir a imagem do processo*/
			syslog(LOG_ERR,"N�o foi possivel executar %s\n",args[0]);
			exit(-1);
		}
	
	}else if(child!=-1){
		
		/*O pai em casos normais entra aqui*/
		if(wait(&status)!=child){
			/*Houve algum problema no processo filho*/
			syslog(LOG_ERR,"Pid retornado pelo processo filho nao corresponde ao esperado pelo pai. Mensagem da funcao exec do PostgreSQL\n");
			erro = -1;

		}else if(!WIFEXITED(status)){	
			/*Processo filho nao terminou normalmente*/
			syslog(LOG_ERR,"Comando executado nao terminou normalmente. Mensagem da funcao exec do PostgreSQL\n");
			erro = -1;
		}

	}else{
		/*O pai caso nao tenha conseguido dar um fork entra aqui*/
		syslog(LOG_ERR,"Funcao exec do PostgreSQL nao conseguiu dar um fork\n");
		erro = -1;
	}
	
	pfree(args[0]);
	
	if(erro){
		/*Eh, tivemos problemas na execucao do processo filho. Mas 
		fazer o que ne? Nem tudo na vida acontece como a gente quer.
		Observe as mensagens do syslog para ver o que pode ter ocorrido.*/
		PG_RETURN_INT32(-1);
	}
	
	/*Amem! O processo filho terminou normalmente. Vamos
	retornar o valor de retorno dele.*/
	
	PG_RETURN_INT32(WEXITSTATUS(status));
}

PG_FUNCTION_INFO_V1(exec2);

Datum exec2(PG_FUNCTION_ARGS){

	pid_t child; /*Pid do processo filho criado*/
	int status;  /*status de terminacao do processo filho*/
	
	/*Argumentos passados a funcao*/

	text	*param0 = PG_GETARG_TEXT_P(0);
	text	*param1 = PG_GETARG_TEXT_P(1);

	/*Variaveis das strings de comando*/
	
	char *args[3];

	erro = 0;
	
	/*+1 para o caracter de nulo*/
	args[0] = (char *) palloc(VARSIZE(param0)+1-VARHDRSZ);
	args[1] = (char *) palloc(VARSIZE(param1)+1-VARHDRSZ);
		
	memcpy(args[0],VARDATA(param0),VARSIZE(param0)-VARHDRSZ);
	memcpy(args[1],VARDATA(param1),VARSIZE(param1)-VARHDRSZ);
	
	args[0][VARSIZE(param0)-VARHDRSZ]='\0';
	args[1][VARSIZE(param1)-VARHDRSZ]='\0';	
	args[2]=NULL;
		
	/*Fork em um novo processo*/
	if(!(child=vfork())){
		/*O processo filho entra aqui*/
		
		/*Substitui a imagem de memoria do processo*/
		syslog(LOG_INFO,"PostgreSQL executando o comando %s %s\n",args[0],args[1]);
		if(execve(args[0],args,environ)==-1){
			/*Nao foi possivel substituir a imagem do processo*/
			syslog(LOG_ERR,"N�o foi possivel executar %s %s\n",args[0],args[1]);
			exit(-1);
		}
	
	}else if(child!=-1){
		
		/*O pai em casos normais entra aqui*/
		if(wait(&status)!=child){
			/*Houve algum problema no processo filho*/
			syslog(LOG_ERR,"Pid retornado pelo processo filho nao corresponde ao esperado pelo pai. Mensagem da funcao exec do PostgreSQL\n");
			erro = -1;

		}else if(!WIFEXITED(status)){	
			/*Processo filho nao terminou normalmente*/
			syslog(LOG_ERR,"Comando executado nao terminou normalmente. Mensagem da funcao exec do PostgreSQL\n");
			erro = -1;
		}

	}else{
		/*O pai caso nao tenha conseguido dar um fork entra aqui*/
		syslog(LOG_ERR,"Funcao exec do PostgreSQL nao conseguiu dar um fork\n");
		erro = -1;
	}
	

	pfree(args[0]);
	pfree(args[1]);
	
	if(erro){
		/*Eh, tivemos problemas na execucao do processo filho. Mas 
		fazer o que ne? Nem tudo na vida acontece como a gente quer.
		Observe as mensagens do syslog para ver o que pode ter ocorrido.*/
		PG_RETURN_INT32(-1);
	}
	
	/*Amem! O processo filho terminou normalmente. Vamos
	retornar o valor de retorno dele.*/
	
	PG_RETURN_INT32(WEXITSTATUS(status));
}



PG_FUNCTION_INFO_V1(exec3);

Datum exec3(PG_FUNCTION_ARGS){

	pid_t child; /*Pid do processo filho criado*/
	int status;  /*status de terminacao do processo filho*/
	
	/*Argumentos passados a funcao*/

	text	*param0 = PG_GETARG_TEXT_P(0);
	text	*param1 = PG_GETARG_TEXT_P(1);
	text    *param2 = PG_GETARG_TEXT_P(2);

	/*Variaveis das strings de comando*/
	

	char *args[4];

	erro = 0;
	
	/*+1 para o caracter de nulo*/


	args[0] = (char *) palloc(VARSIZE(param0)+1-VARHDRSZ);
	args[1] = (char *) palloc(VARSIZE(param1)+1-VARHDRSZ);
	args[2] = (char *) palloc(VARSIZE(param2)+1-VARHDRSZ);
	

	memcpy(args[0],VARDATA(param0),VARSIZE(param0)-VARHDRSZ);
	memcpy(args[1],VARDATA(param1),VARSIZE(param1)-VARHDRSZ);
	memcpy(args[2],VARDATA(param2),VARSIZE(param2)-VARHDRSZ);
	
	
	args[0][VARSIZE(param0)-VARHDRSZ]='\0';
	args[1][VARSIZE(param1)-VARHDRSZ]='\0';
	args[2][VARSIZE(param2)-VARHDRSZ]='\0';
	args[3]=NULL;
		
	/*Fork em um novo processo*/
	if(!(child=vfork())){
		/*O processo filho entra aqui*/
		
		/*Substitui a imagem de memoria do processo*/
		syslog(LOG_INFO,"PostgreSQL executando o comando %s %s %s\n",args[0],args[1],args[2]);
		if(execve(args[0],args,environ)==-1){
			/*Nao foi possivel substituir a imagem do processo*/
			syslog(LOG_ERR,"N�o foi possivel executar %s %s %s\n",args[0],args[1],args[2]);
			exit(-1);
		}
	
	}else if(child!=-1){
		
		/*O pai em casos normais entra aqui*/
		if(wait(&status)!=child){
			/*Houve algum problema no processo filho*/
			syslog(LOG_ERR,"Pid retornado pelo processo filho nao corresponde ao esperado pelo pai. Mensagem da funcao exec do PostgreSQL\n");
			erro = -1;

		}else if(!WIFEXITED(status)){	
			/*Processo filho nao terminou normalmente*/
			syslog(LOG_ERR,"Comando executado nao terminou normalmente. Mensagem da funcao exec do PostgreSQL\n");
			erro = -1;
		}

	}else{
		/*O pai caso nao tenha conseguido dar um fork entra aqui*/
		syslog(LOG_ERR,"Funcao exec do PostgreSQL nao conseguiu dar um fork\n");
		erro = -1;
	}
	
	pfree(args[0]);
	pfree(args[1]);
	pfree(args[2]);
	
	if(erro){
		/*Eh, tivemos problemas na execucao do processo filho. Mas 
		fazer o que ne? Nem tudo na vida acontece como a gente quer.
		Observe as mensagens do syslog para ver o que pode ter ocorrido.*/
		PG_RETURN_INT32(-1);
	}
	
	/*Amem! O processo filho terminou normalmente. Vamos
	retornar o valor de retorno dele.*/
	
	PG_RETURN_INT32(WEXITSTATUS(status));
}

PG_FUNCTION_INFO_V1(exec4);

Datum exec4(PG_FUNCTION_ARGS){

	pid_t child; /*Pid do processo filho criado*/
	int status;  /*status de terminacao do processo filho*/
	
	/*Argumentos passados a funcao*/

	text	*param0 = PG_GETARG_TEXT_P(0);
	text	*param1 = PG_GETARG_TEXT_P(1);
	text    *param2 = PG_GETARG_TEXT_P(2);
	text	*param3 = PG_GETARG_TEXT_P(3);
	
	/*Variaveis das strings de comando*/
	

	char *args[5];

	erro = 0;
	
	/*+1 para o caracter de nulo*/

	args[0] = (char *) palloc(VARSIZE(param0)+1-VARHDRSZ);
	args[1] = (char *) palloc(VARSIZE(param1)+1-VARHDRSZ);
	args[2] = (char *) palloc(VARSIZE(param2)+1-VARHDRSZ);
	args[3] = (char *) palloc(VARSIZE(param3)+1-VARHDRSZ);
	

	memcpy(args[0],VARDATA(param0),VARSIZE(param0)-VARHDRSZ);
	memcpy(args[1],VARDATA(param1),VARSIZE(param1)-VARHDRSZ);
	memcpy(args[2],VARDATA(param2),VARSIZE(param2)-VARHDRSZ);
	memcpy(args[3],VARDATA(param3),VARSIZE(param3)-VARHDRSZ);
	

	args[0][VARSIZE(param0)-VARHDRSZ]='\0';
	args[1][VARSIZE(param1)-VARHDRSZ]='\0';
	args[2][VARSIZE(param2)-VARHDRSZ]='\0';
	args[3][VARSIZE(param3)-VARHDRSZ]='\0';
	args[4]=NULL;
		
	/*Fork em um novo processo*/
	if(!(child=vfork())){
		/*O processo filho entra aqui*/
		
		/*Substitui a imagem de memoria do processo*/
		syslog(LOG_INFO,"PostgreSQL executando o comando %s %s %s %s\n",args[0],args[1],args[2],args[3]);
		if(execve(args[0],args,environ)==-1){
			/*Nao foi possivel substituir a imagem do processo*/
			syslog(LOG_ERR,"N�o foi possivel executar %s %s %s %s\n",args[0],args[1],args[2],args[3]);
			exit(-1);
		}
	
	}else if(child!=-1){
		
		/*O pai em casos normais entra aqui*/
		if(wait(&status)!=child){
			/*Houve algum problema no processo filho*/
			syslog(LOG_ERR,"Pid retornado pelo processo filho nao corresponde ao esperado pelo pai. Mensagem da funcao exec do PostgreSQL\n");
			erro = -1;

		}else if(!WIFEXITED(status)){	
			/*Processo filho nao terminou normalmente*/
			syslog(LOG_ERR,"Comando executado nao terminou normalmente. Mensagem da funcao exec do PostgreSQL\n");
			erro = -1;
		}

	}else{
		/*O pai caso nao tenha conseguido dar um fork entra aqui*/
		syslog(LOG_ERR,"Funcao exec do PostgreSQL nao conseguiu dar um fork\n");
		erro = -1;
	}
	

	pfree(args[0]);
	pfree(args[1]);
	pfree(args[2]);
	pfree(args[3]);
	
	if(erro){
		/*Eh, tivemos problemas na execucao do processo filho. Mas 
		fazer o que ne? Nem tudo na vida acontece como a gente quer.
		Observe as mensagens do syslog para ver o que pode ter ocorrido.*/
		PG_RETURN_INT32(-1);
	}
	
	/*Amem! O processo filho terminou normalmente. Vamos
	retornar o valor de retorno dele.*/
	
	PG_RETURN_INT32(WEXITSTATUS(status));
}

PG_FUNCTION_INFO_V1(exec5);

Datum exec5(PG_FUNCTION_ARGS){

	pid_t child; /*Pid do processo filho criado*/
	int status;  /*status de terminacao do processo filho*/
	
	/*Argumentos passados a funcao*/

	text	*param0 = PG_GETARG_TEXT_P(0);
	text	*param1 = PG_GETARG_TEXT_P(1);
	text  *param2 = PG_GETARG_TEXT_P(2);
	text	*param3 = PG_GETARG_TEXT_P(3);
	text	*param4 = PG_GETARG_TEXT_P(4);
	
	/*Variaveis das strings de comando*/
	

	char *args[6];

	erro = 0;
	
	/*+1 para o caracter de nulo*/

	args[0] = (char *) palloc(VARSIZE(param0)+1-VARHDRSZ);
	args[1] = (char *) palloc(VARSIZE(param1)+1-VARHDRSZ);
	args[2] = (char *) palloc(VARSIZE(param2)+1-VARHDRSZ);
	args[3] = (char *) palloc(VARSIZE(param3)+1-VARHDRSZ);
	args[4] = (char *) palloc(VARSIZE(param4)+1-VARHDRSZ);
	

	memcpy(args[0],VARDATA(param0),VARSIZE(param0)-VARHDRSZ);
	memcpy(args[1],VARDATA(param1),VARSIZE(param1)-VARHDRSZ);
	memcpy(args[2],VARDATA(param2),VARSIZE(param2)-VARHDRSZ);
	memcpy(args[3],VARDATA(param3),VARSIZE(param3)-VARHDRSZ);
	memcpy(args[4],VARDATA(param4),VARSIZE(param4)-VARHDRSZ);
	

	args[0][VARSIZE(param0)-VARHDRSZ]='\0';
	args[1][VARSIZE(param1)-VARHDRSZ]='\0';
	args[2][VARSIZE(param2)-VARHDRSZ]='\0';
	args[3][VARSIZE(param3)-VARHDRSZ]='\0';
	args[4][VARSIZE(param4)-VARHDRSZ]='\0';
	args[5]=NULL;
		
	/*Fork em um novo processo*/
	if(!(child=vfork())){
		/*O processo filho entra aqui*/
		
		/*Substitui a imagem de memoria do processo*/
		syslog(LOG_INFO,"PostgreSQL executando o comando %s %s %s %s %s\n",args[0],args[1],args[2],args[3],args[4]);
		if(execve(args[0],args,environ)==-1){
			/*Nao foi possivel substituir a imagem do processo*/
			syslog(LOG_ERR,"N�o foi possivel executar %s %s %s %s %s\n",args[0],args[1],args[2],args[3],args[4]);
			exit(-1);
		}
	
	}else if(child!=-1){
		
		/*O pai em casos normais entra aqui*/
		if(wait(&status)!=child){
			/*Houve algum problema no processo filho*/
			syslog(LOG_ERR,"Pid retornado pelo processo filho nao corresponde ao esperado pelo pai. Mensagem da funcao exec do PostgreSQL\n");
			erro = -1;

		}else if(!WIFEXITED(status)){	
			/*Processo filho nao terminou normalmente*/
			syslog(LOG_ERR,"Comando executado nao terminou normalmente. Mensagem da funcao exec do PostgreSQL\n");
			erro = -1;
		}

	}else{
		/*O pai caso nao tenha conseguido dar um fork entra aqui*/
		syslog(LOG_ERR,"Funcao exec do PostgreSQL nao conseguiu dar um fork\n");
		erro = -1;
	}
	

	pfree(args[0]);
	pfree(args[1]);
	pfree(args[2]);
	pfree(args[3]);
	pfree(args[4]);
	
	if(erro){
		/*Eh, tivemos problemas na execucao do processo filho. Mas 
		fazer o que ne? Nem tudo na vida acontece como a gente quer.
		Observe as mensagens do syslog para ver o que pode ter ocorrido.*/
		PG_RETURN_INT32(-1);
	}
	
	/*Amem! O processo filho terminou normalmente. Vamos
	retornar o valor de retorno dele.*/
	
	PG_RETURN_INT32(WEXITSTATUS(status));
}

PG_FUNCTION_INFO_V1(exec6);

Datum exec6(PG_FUNCTION_ARGS){

	pid_t child; /*Pid do processo filho criado*/
	int status;  /*status de terminacao do processo filho*/
	
	/*Argumentos passados a funcao*/

	text	*param0 = PG_GETARG_TEXT_P(0);
	text	*param1 = PG_GETARG_TEXT_P(1);
	text    *param2 = PG_GETARG_TEXT_P(2);
	text	*param3 = PG_GETARG_TEXT_P(3);
	text	*param4	= PG_GETARG_TEXT_P(4);
	text	*param5 = PG_GETARG_TEXT_P(5);
	
	/*Variaveis das strings de comando*/
	

	char *args[7];

	erro = 0;
	
	/*+1 para o caracter de nulo*/

	args[0] = (char *) palloc(VARSIZE(param0)+1-VARHDRSZ);
	args[1] = (char *) palloc(VARSIZE(param1)+1-VARHDRSZ);
	args[2] = (char *) palloc(VARSIZE(param2)+1-VARHDRSZ);
	args[3] = (char *) palloc(VARSIZE(param3)+1-VARHDRSZ);
	args[4] = (char *) palloc(VARSIZE(param4)+1-VARHDRSZ);
	args[5] = (char *) palloc(VARSIZE(param5)+1-VARHDRSZ);
	

	memcpy(args[0],VARDATA(param0),VARSIZE(param0)-VARHDRSZ);
	memcpy(args[1],VARDATA(param1),VARSIZE(param1)-VARHDRSZ);
	memcpy(args[2],VARDATA(param2),VARSIZE(param2)-VARHDRSZ);
	memcpy(args[3],VARDATA(param3),VARSIZE(param3)-VARHDRSZ);
	memcpy(args[4],VARDATA(param4),VARSIZE(param4)-VARHDRSZ);
	memcpy(args[5],VARDATA(param5),VARSIZE(param5)-VARHDRSZ);
	

	args[0][VARSIZE(param0)-VARHDRSZ]='\0';
	args[1][VARSIZE(param1)-VARHDRSZ]='\0';
	args[2][VARSIZE(param2)-VARHDRSZ]='\0';
	args[3][VARSIZE(param3)-VARHDRSZ]='\0';
	args[4][VARSIZE(param4)-VARHDRSZ]='\0';
	args[5][VARSIZE(param5)-VARHDRSZ]='\0';
	args[6]=NULL;
		
	/*Fork em um novo processo*/
	if(!(child=vfork())){
		/*O processo filho entra aqui*/
		
		/*Substitui a imagem de memoria do processo*/
		syslog(LOG_INFO,"PostgreSQL executando o comando %s %s %s %s %s %s\n",args[0],args[1],args[2],args[3],args[4],args[5]);
		if(execve(args[0],args,environ)==-1){
			/*Nao foi possivel substituir a imagem do processo*/
			syslog(LOG_ERR,"N�o foi possivel executar %s %s %s %s %s %s\n",args[0],args[1],args[2],args[3],args[4],args[5]);
			exit(-1);
		}
	
	}else if(child!=-1){
		
		/*O pai em casos normais entra aqui*/
		if(wait(&status)!=child){
			/*Houve algum problema no processo filho*/
			syslog(LOG_ERR,"Pid retornado pelo processo filho nao corresponde ao esperado pelo pai. Mensagem da funcao exec do PostgreSQL\n");
			erro = -1;

		}else if(!WIFEXITED(status)){	
			/*Processo filho nao terminou normalmente*/
			syslog(LOG_ERR,"Comando executado nao terminou normalmente. Mensagem da funcao exec do PostgreSQL\n");
			erro = -1;
		}

	}else{
		/*O pai caso nao tenha conseguido dar um fork entra aqui*/
		syslog(LOG_ERR,"Funcao exec do PostgreSQL nao conseguiu dar um fork\n");
		erro = -1;
	}
	

	pfree(args[0]);
	pfree(args[1]);
	pfree(args[2]);
	pfree(args[3]);
	pfree(args[4]);
	pfree(args[5]);
	
	if(erro){
		/*Eh, tivemos problemas na execucao do processo filho. Mas 
		fazer o que ne? Nem tudo na vida acontece como a gente quer.
		Observe as mensagens do syslog para ver o que pode ter ocorrido.*/
		PG_RETURN_INT32(-1);
	}
	
	/*Amem! O processo filho terminou normalmente. Vamos
	retornar o valor de retorno dele.*/
	
	PG_RETURN_INT32(WEXITSTATUS(status));
}

PG_FUNCTION_INFO_V1(exec7);

Datum exec7(PG_FUNCTION_ARGS){

	pid_t child; /*Pid do processo filho criado*/
	int status;  /*status de terminacao do processo filho*/
	
	/*Argumentos passados a funcao*/

	text	*param0 = PG_GETARG_TEXT_P(0);
	text	*param1 = PG_GETARG_TEXT_P(1);
	text    *param2 = PG_GETARG_TEXT_P(2);
	text	*param3 = PG_GETARG_TEXT_P(3);
	text	*param4	= PG_GETARG_TEXT_P(4);
	text	*param5 = PG_GETARG_TEXT_P(5);
	text    *param6 = PG_GETARG_TEXT_P(6);

	/*Variaveis das strings de comando*/


	char *args[8];

	erro = 0;

	/*+1 para o caracter de nulo*/

	args[0] = (char *) palloc(VARSIZE(param0)+1-VARHDRSZ);
	args[1] = (char *) palloc(VARSIZE(param1)+1-VARHDRSZ);
	args[2] = (char *) palloc(VARSIZE(param2)+1-VARHDRSZ);
	args[3] = (char *) palloc(VARSIZE(param3)+1-VARHDRSZ);
	args[4] = (char *) palloc(VARSIZE(param4)+1-VARHDRSZ);
	args[5] = (char *) palloc(VARSIZE(param5)+1-VARHDRSZ);
	args[6] = (char *) palloc(VARSIZE(param6)+1-VARHDRSZ);


	memcpy(args[0],VARDATA(param0),VARSIZE(param0)-VARHDRSZ);
	memcpy(args[1],VARDATA(param1),VARSIZE(param1)-VARHDRSZ);
	memcpy(args[2],VARDATA(param2),VARSIZE(param2)-VARHDRSZ);
	memcpy(args[3],VARDATA(param3),VARSIZE(param3)-VARHDRSZ);
	memcpy(args[4],VARDATA(param4),VARSIZE(param4)-VARHDRSZ);
	memcpy(args[5],VARDATA(param5),VARSIZE(param5)-VARHDRSZ);
	memcpy(args[6],VARDATA(param6),VARSIZE(param6)-VARHDRSZ);


	args[0][VARSIZE(param0)-VARHDRSZ]='\0';
	args[1][VARSIZE(param1)-VARHDRSZ]='\0';
	args[2][VARSIZE(param2)-VARHDRSZ]='\0';
	args[3][VARSIZE(param3)-VARHDRSZ]='\0';
	args[4][VARSIZE(param4)-VARHDRSZ]='\0';
	args[5][VARSIZE(param5)-VARHDRSZ]='\0';
	args[6][VARSIZE(param6)-VARHDRSZ]='\0';
	args[7]=NULL;

	/*Fork em um novo processo*/
	if(!(child=vfork())){
		/*O processo filho entra aqui*/

		/*Substitui a imagem de memoria do processo*/
		syslog(LOG_INFO,"PostgreSQL executando o comando %s %s %s %s %s %s %s\n",args[0],args[1],args[2],args[3],args[4],args[5],args[6]);
		if(execve(args[0],args,environ)==-1){
			/*Nao foi possivel substituir a imagem do processo*/
			syslog(LOG_ERR,"N�o foi possivel executar %s %s %s %s %s %s %s\n",args[0],args[1],args[2],args[3],args[4],args[5],args[6]);
			exit(-1);
		}

	}else if(child!=-1){

		/*O pai em casos normais entra aqui*/
		if(wait(&status)!=child){
			/*Houve algum problema no processo filho*/
			syslog(LOG_ERR,"Pid retornado pelo processo filho nao corresponde ao esperado pelo pai. Mensagem da funcao exec do PostgreSQL\n");
			erro = -1;

		}else if(!WIFEXITED(status)){
			/*Processo filho nao terminou normalmente*/
			syslog(LOG_ERR,"Comando executado nao terminou normalmente. Mensagem da funcao exec do PostgreSQL\n");
			erro = -1;
		}

	}else{
		/*O pai caso nao tenha conseguido dar um fork entra aqui*/
		syslog(LOG_ERR,"Funcao exec do PostgreSQL nao conseguiu dar um fork\n");
		erro = -1;
	}


	pfree(args[0]);
	pfree(args[1]);
	pfree(args[2]);
	pfree(args[3]);
	pfree(args[4]);
	pfree(args[5]);
	pfree(args[6]);

	if(erro){
		/*Eh, tivemos problemas na execucao do processo filho. Mas
		fazer o que ne? Nem tudo na vida acontece como a gente quer.
		Observe as mensagens do syslog para ver o que pode ter ocorrido.*/
		PG_RETURN_INT32(-1);
	}

	/*Amem! O processo filho terminou normalmente. Vamos
	retornar o valor de retorno dele.*/

	PG_RETURN_INT32(WEXITSTATUS(status));
}

PG_FUNCTION_INFO_V1(exec8);

Datum exec8(PG_FUNCTION_ARGS){

	pid_t child; /*Pid do processo filho criado*/
	int status;  /*status de terminacao do processo filho*/

	/*Argumentos passados a funcao*/

	text	*param0 = PG_GETARG_TEXT_P(0);
	text	*param1 = PG_GETARG_TEXT_P(1);
	text    *param2 = PG_GETARG_TEXT_P(2);
	text	*param3 = PG_GETARG_TEXT_P(3);
	text	*param4	= PG_GETARG_TEXT_P(4);
	text	*param5 = PG_GETARG_TEXT_P(5);
	text    *param6 = PG_GETARG_TEXT_P(6);
    text    *param7 = PG_GETARG_TEXT_P(7);

	/*Variaveis das strings de comando*/


	char *args[9];

	erro = 0;

	/*+1 para o caracter de nulo*/

	args[0] = (char *) palloc(VARSIZE(param0)+1-VARHDRSZ);
	args[1] = (char *) palloc(VARSIZE(param1)+1-VARHDRSZ);
	args[2] = (char *) palloc(VARSIZE(param2)+1-VARHDRSZ);
	args[3] = (char *) palloc(VARSIZE(param3)+1-VARHDRSZ);
	args[4] = (char *) palloc(VARSIZE(param4)+1-VARHDRSZ);
	args[5] = (char *) palloc(VARSIZE(param5)+1-VARHDRSZ);
	args[6] = (char *) palloc(VARSIZE(param6)+1-VARHDRSZ);
    args[7] = (char *) palloc(VARSIZE(param7)+1-VARHDRSZ);


	memcpy(args[0],VARDATA(param0),VARSIZE(param0)-VARHDRSZ);
	memcpy(args[1],VARDATA(param1),VARSIZE(param1)-VARHDRSZ);
	memcpy(args[2],VARDATA(param2),VARSIZE(param2)-VARHDRSZ);
	memcpy(args[3],VARDATA(param3),VARSIZE(param3)-VARHDRSZ);
	memcpy(args[4],VARDATA(param4),VARSIZE(param4)-VARHDRSZ);
	memcpy(args[5],VARDATA(param5),VARSIZE(param5)-VARHDRSZ);
	memcpy(args[6],VARDATA(param6),VARSIZE(param6)-VARHDRSZ);
    memcpy(args[7],VARDATA(param7),VARSIZE(param7)-VARHDRSZ);


	args[0][VARSIZE(param0)-VARHDRSZ]='\0';
	args[1][VARSIZE(param1)-VARHDRSZ]='\0';
	args[2][VARSIZE(param2)-VARHDRSZ]='\0';
	args[3][VARSIZE(param3)-VARHDRSZ]='\0';
	args[4][VARSIZE(param4)-VARHDRSZ]='\0';
	args[5][VARSIZE(param5)-VARHDRSZ]='\0';
	args[6][VARSIZE(param6)-VARHDRSZ]='\0';
    args[7][VARSIZE(param7)-VARHDRSZ]='\0';
	args[8]=NULL;

	/*Fork em um novo processo*/
	if(!(child=vfork())){
		/*O processo filho entra aqui*/

		/*Substitui a imagem de memoria do processo*/
		syslog(LOG_INFO,"PostgreSQL executando o comando %s %s %s %s %s %s %s %s\n",args[0],args[1],args[2],args[3],args[4],args[5],args[6],args[7]);
		if(execve(args[0],args,environ)==-1){
			/*Nao foi possivel substituir a imagem do processo*/
			syslog(LOG_ERR,"N�o foi possivel executar %s %s %s %s %s %s %s %s\n",args[0],args[1],args[2],args[3],args[4],args[5],args[6],args[7]);
			exit(-1);
		}

	}else if(child!=-1){

		/*O pai em casos normais entra aqui*/
		if(wait(&status)!=child){
			/*Houve algum problema no processo filho*/
			syslog(LOG_ERR,"Pid retornado pelo processo filho nao corresponde ao esperado pelo pai. Mensagem da funcao exec do PostgreSQL\n");
			erro = -1;

		}else if(!WIFEXITED(status)){
			/*Processo filho nao terminou normalmente*/
			syslog(LOG_ERR,"Comando executado nao terminou normalmente. Mensagem da funcao exec do PostgreSQL\n");
			erro = -1;
		}

	}else{
		/*O pai caso nao tenha conseguido dar um fork entra aqui*/
		syslog(LOG_ERR,"Funcao exec do PostgreSQL nao conseguiu dar um fork\n");
		erro = -1;
	}


	pfree(args[0]);
	pfree(args[1]);
	pfree(args[2]);
	pfree(args[3]);
	pfree(args[4]);
	pfree(args[5]);
	pfree(args[6]);
    pfree(args[7]);

	if(erro){
		/*Eh, tivemos problemas na execucao do processo filho. Mas
		fazer o que ne? Nem tudo na vida acontece como a gente quer.
		Observe as mensagens do syslog para ver o que pode ter ocorrido.*/
		PG_RETURN_INT32(-1);
	}

	/*Amem! O processo filho terminou normalmente. Vamos
	retornar o valor de retorno dele.*/

	PG_RETURN_INT32(WEXITSTATUS(status));
}

PG_FUNCTION_INFO_V1(exec9);

Datum exec9(PG_FUNCTION_ARGS){

	pid_t child; /*Pid do processo filho criado*/
	int status;  /*status de terminacao do processo filho*/

	/*Argumentos passados a funcao*/

	text	*param0 = PG_GETARG_TEXT_P(0);
	text	*param1 = PG_GETARG_TEXT_P(1);
	text    *param2 = PG_GETARG_TEXT_P(2);
	text	*param3 = PG_GETARG_TEXT_P(3);
	text	*param4	= PG_GETARG_TEXT_P(4);
	text	*param5 = PG_GETARG_TEXT_P(5);
	text    *param6 = PG_GETARG_TEXT_P(6);
    text    *param7 = PG_GETARG_TEXT_P(7);
    text    *param8 = PG_GETARG_TEXT_P(8);

	/*Variaveis das strings de comando*/


	char *args[10];

	erro = 0;

	/*+1 para o caracter de nulo*/

	args[0] = (char *) palloc(VARSIZE(param0)+1-VARHDRSZ);
	args[1] = (char *) palloc(VARSIZE(param1)+1-VARHDRSZ);
	args[2] = (char *) palloc(VARSIZE(param2)+1-VARHDRSZ);
	args[3] = (char *) palloc(VARSIZE(param3)+1-VARHDRSZ);
	args[4] = (char *) palloc(VARSIZE(param4)+1-VARHDRSZ);
	args[5] = (char *) palloc(VARSIZE(param5)+1-VARHDRSZ);
	args[6] = (char *) palloc(VARSIZE(param6)+1-VARHDRSZ);
    args[7] = (char *) palloc(VARSIZE(param7)+1-VARHDRSZ);
    args[8] = (char *) palloc(VARSIZE(param8)+1-VARHDRSZ);


	memcpy(args[0],VARDATA(param0),VARSIZE(param0)-VARHDRSZ);
	memcpy(args[1],VARDATA(param1),VARSIZE(param1)-VARHDRSZ);
	memcpy(args[2],VARDATA(param2),VARSIZE(param2)-VARHDRSZ);
	memcpy(args[3],VARDATA(param3),VARSIZE(param3)-VARHDRSZ);
	memcpy(args[4],VARDATA(param4),VARSIZE(param4)-VARHDRSZ);
	memcpy(args[5],VARDATA(param5),VARSIZE(param5)-VARHDRSZ);
	memcpy(args[6],VARDATA(param6),VARSIZE(param6)-VARHDRSZ);
    memcpy(args[7],VARDATA(param7),VARSIZE(param7)-VARHDRSZ);
    memcpy(args[8],VARDATA(param8),VARSIZE(param8)-VARHDRSZ);


	args[0][VARSIZE(param0)-VARHDRSZ]='\0';
	args[1][VARSIZE(param1)-VARHDRSZ]='\0';
	args[2][VARSIZE(param2)-VARHDRSZ]='\0';
	args[3][VARSIZE(param3)-VARHDRSZ]='\0';
	args[4][VARSIZE(param4)-VARHDRSZ]='\0';
	args[5][VARSIZE(param5)-VARHDRSZ]='\0';
	args[6][VARSIZE(param6)-VARHDRSZ]='\0';
    args[7][VARSIZE(param7)-VARHDRSZ]='\0';
    args[8][VARSIZE(param8)-VARHDRSZ]='\0';
	args[9]=NULL;

	/*Fork em um novo processo*/
	if(!(child=vfork())){
		/*O processo filho entra aqui*/

		/*Substitui a imagem de memoria do processo*/
		syslog(LOG_INFO,"PostgreSQL executando o comando %s %s %s %s %s %s %s %s %s\n",args[0],args[1],args[2],args[3],args[4],args[5],args[6],args[7],args[8]);
		if(execve(args[0],args,environ)==-1){
			/*Nao foi possivel substituir a imagem do processo*/
			syslog(LOG_ERR,"N�o foi possivel executar %s %s %s %s %s %s %s %s %s\n",args[0],args[1],args[2],args[3],args[4],args[5],args[6],args[7],args[8]);
			exit(-1);
		}

	}else if(child!=-1){

		/*O pai em casos normais entra aqui*/
		if(wait(&status)!=child){
			/*Houve algum problema no processo filho*/
			syslog(LOG_ERR,"Pid retornado pelo processo filho nao corresponde ao esperado pelo pai. Mensagem da funcao exec do PostgreSQL\n");
			erro = -1;

		}else if(!WIFEXITED(status)){
			/*Processo filho nao terminou normalmente*/
			syslog(LOG_ERR,"Comando executado nao terminou normalmente. Mensagem da funcao exec do PostgreSQL\n");
			erro = -1;
		}

	}else{
		/*O pai caso nao tenha conseguido dar um fork entra aqui*/
		syslog(LOG_ERR,"Funcao exec do PostgreSQL nao conseguiu dar um fork\n");
		erro = -1;
	}


	pfree(args[0]);
	pfree(args[1]);
	pfree(args[2]);
	pfree(args[3]);
	pfree(args[4]);
	pfree(args[5]);
	pfree(args[6]);
    pfree(args[7]);
    pfree(args[8]);

	if(erro){
		/*Eh, tivemos problemas na execucao do processo filho. Mas
		fazer o que ne? Nem tudo na vida acontece como a gente quer.
		Observe as mensagens do syslog para ver o que pode ter ocorrido.*/
		PG_RETURN_INT32(-1);
	}

	/*Amem! O processo filho terminou normalmente. Vamos
	retornar o valor de retorno dele.*/

	PG_RETURN_INT32(WEXITSTATUS(status));
}

PG_FUNCTION_INFO_V1(exec10);

Datum exec10(PG_FUNCTION_ARGS){

	pid_t child; /*Pid do processo filho criado*/
	int status;  /*status de terminacao do processo filho*/

	/*Argumentos passados a funcao*/

	text	*param0 = PG_GETARG_TEXT_P(0);
	text	*param1 = PG_GETARG_TEXT_P(1);
	text    *param2 = PG_GETARG_TEXT_P(2);
	text	*param3 = PG_GETARG_TEXT_P(3);
	text	*param4	= PG_GETARG_TEXT_P(4);
	text	*param5 = PG_GETARG_TEXT_P(5);
	text    *param6 = PG_GETARG_TEXT_P(6);
    text    *param7 = PG_GETARG_TEXT_P(7);
    text    *param8 = PG_GETARG_TEXT_P(8);
    text    *param9 = PG_GETARG_TEXT_P(9);

	/*Variaveis das strings de comando*/


	char *args[11];

	erro = 0;

	/*+1 para o caracter de nulo*/

	args[0] = (char *) palloc(VARSIZE(param0)+1-VARHDRSZ);
	args[1] = (char *) palloc(VARSIZE(param1)+1-VARHDRSZ);
	args[2] = (char *) palloc(VARSIZE(param2)+1-VARHDRSZ);
	args[3] = (char *) palloc(VARSIZE(param3)+1-VARHDRSZ);
	args[4] = (char *) palloc(VARSIZE(param4)+1-VARHDRSZ);
	args[5] = (char *) palloc(VARSIZE(param5)+1-VARHDRSZ);
	args[6] = (char *) palloc(VARSIZE(param6)+1-VARHDRSZ);
    args[7] = (char *) palloc(VARSIZE(param7)+1-VARHDRSZ);
    args[8] = (char *) palloc(VARSIZE(param8)+1-VARHDRSZ);
    args[9] = (char *) palloc(VARSIZE(param9)+1-VARHDRSZ);


	memcpy(args[0],VARDATA(param0),VARSIZE(param0)-VARHDRSZ);
	memcpy(args[1],VARDATA(param1),VARSIZE(param1)-VARHDRSZ);
	memcpy(args[2],VARDATA(param2),VARSIZE(param2)-VARHDRSZ);
	memcpy(args[3],VARDATA(param3),VARSIZE(param3)-VARHDRSZ);
	memcpy(args[4],VARDATA(param4),VARSIZE(param4)-VARHDRSZ);
	memcpy(args[5],VARDATA(param5),VARSIZE(param5)-VARHDRSZ);
	memcpy(args[6],VARDATA(param6),VARSIZE(param6)-VARHDRSZ);
    memcpy(args[7],VARDATA(param7),VARSIZE(param7)-VARHDRSZ);
    memcpy(args[8],VARDATA(param8),VARSIZE(param8)-VARHDRSZ);
    memcpy(args[9],VARDATA(param9),VARSIZE(param9)-VARHDRSZ);


	args[0][VARSIZE(param0)-VARHDRSZ]='\0';
	args[1][VARSIZE(param1)-VARHDRSZ]='\0';
	args[2][VARSIZE(param2)-VARHDRSZ]='\0';
	args[3][VARSIZE(param3)-VARHDRSZ]='\0';
	args[4][VARSIZE(param4)-VARHDRSZ]='\0';
	args[5][VARSIZE(param5)-VARHDRSZ]='\0';
	args[6][VARSIZE(param6)-VARHDRSZ]='\0';
    args[7][VARSIZE(param7)-VARHDRSZ]='\0';
    args[8][VARSIZE(param8)-VARHDRSZ]='\0';
    args[9][VARSIZE(param9)-VARHDRSZ]='\0';
	args[10]=NULL;

	/*Fork em um novo processo*/
	if(!(child=vfork())){
		/*O processo filho entra aqui*/

		/*Substitui a imagem de memoria do processo*/
		syslog(LOG_INFO,"PostgreSQL executando o comando %s %s %s %s %s %s %s %s %s %s\n",args[0],args[1],args[2],args[3],args[4],args[5],args[6],args[7],args[8],args[9]);
		if(execve(args[0],args,environ)==-1){
			/*Nao foi possivel substituir a imagem do processo*/
			syslog(LOG_ERR,"N�o foi possivel executar %s %s %s %s %s %s %s %s %s %s\n",args[0],args[1],args[2],args[3],args[4],args[5],args[6],args[7],args[8],args[9]);
			exit(-1);
		}

	}else if(child!=-1){

		/*O pai em casos normais entra aqui*/
		if(wait(&status)!=child){
			/*Houve algum problema no processo filho*/
			syslog(LOG_ERR,"Pid retornado pelo processo filho nao corresponde ao esperado pelo pai. Mensagem da funcao exec do PostgreSQL\n");
			erro = -1;

		}else if(!WIFEXITED(status)){
			/*Processo filho nao terminou normalmente*/
			syslog(LOG_ERR,"Comando executado nao terminou normalmente. Mensagem da funcao exec do PostgreSQL\n");
			erro = -1;
		}

	}else{
		/*O pai caso nao tenha conseguido dar um fork entra aqui*/
		syslog(LOG_ERR,"Funcao exec do PostgreSQL nao conseguiu dar um fork\n");
		erro = -1;
	}


	pfree(args[0]);
	pfree(args[1]);
	pfree(args[2]);
	pfree(args[3]);
	pfree(args[4]);
	pfree(args[5]);
	pfree(args[6]);
    pfree(args[7]);
    pfree(args[8]);
    pfree(args[9]);

	if(erro){
		/*Eh, tivemos problemas na execucao do processo filho. Mas
		fazer o que ne? Nem tudo na vida acontece como a gente quer.
		Observe as mensagens do syslog para ver o que pode ter ocorrido.*/
		PG_RETURN_INT32(-1);
	}

	/*Amem! O processo filho terminou normalmente. Vamos
	retornar o valor de retorno dele.*/

	PG_RETURN_INT32(WEXITSTATUS(status));
}

PG_FUNCTION_INFO_V1(exec11);

Datum exec11(PG_FUNCTION_ARGS){

	pid_t child; /*Pid do processo filho criado*/
	int status;  /*status de terminacao do processo filho*/

	/*Argumentos passados a funcao*/

	text	*param0 = PG_GETARG_TEXT_P(0);
	text	*param1 = PG_GETARG_TEXT_P(1);
	text    *param2 = PG_GETARG_TEXT_P(2);
	text	*param3 = PG_GETARG_TEXT_P(3);
	text	*param4	= PG_GETARG_TEXT_P(4);
	text	*param5 = PG_GETARG_TEXT_P(5);
	text    *param6 = PG_GETARG_TEXT_P(6);
    text    *param7 = PG_GETARG_TEXT_P(7);
    text    *param8 = PG_GETARG_TEXT_P(8);
    text    *param9 = PG_GETARG_TEXT_P(9);
    text    *param10 = PG_GETARG_TEXT_P(10);

	/*Variaveis das strings de comando*/


	char *args[12];

	erro = 0;

	/*+1 para o caracter de nulo*/

	args[0] = (char *) palloc(VARSIZE(param0)+1-VARHDRSZ);
	args[1] = (char *) palloc(VARSIZE(param1)+1-VARHDRSZ);
	args[2] = (char *) palloc(VARSIZE(param2)+1-VARHDRSZ);
	args[3] = (char *) palloc(VARSIZE(param3)+1-VARHDRSZ);
	args[4] = (char *) palloc(VARSIZE(param4)+1-VARHDRSZ);
	args[5] = (char *) palloc(VARSIZE(param5)+1-VARHDRSZ);
	args[6] = (char *) palloc(VARSIZE(param6)+1-VARHDRSZ);
    args[7] = (char *) palloc(VARSIZE(param7)+1-VARHDRSZ);
    args[8] = (char *) palloc(VARSIZE(param8)+1-VARHDRSZ);
    args[9] = (char *) palloc(VARSIZE(param9)+1-VARHDRSZ);
    args[10] = (char *) palloc(VARSIZE(param10)+1-VARHDRSZ);


	memcpy(args[0],VARDATA(param0),VARSIZE(param0)-VARHDRSZ);
	memcpy(args[1],VARDATA(param1),VARSIZE(param1)-VARHDRSZ);
	memcpy(args[2],VARDATA(param2),VARSIZE(param2)-VARHDRSZ);
	memcpy(args[3],VARDATA(param3),VARSIZE(param3)-VARHDRSZ);
	memcpy(args[4],VARDATA(param4),VARSIZE(param4)-VARHDRSZ);
	memcpy(args[5],VARDATA(param5),VARSIZE(param5)-VARHDRSZ);
	memcpy(args[6],VARDATA(param6),VARSIZE(param6)-VARHDRSZ);
    memcpy(args[7],VARDATA(param7),VARSIZE(param7)-VARHDRSZ);
    memcpy(args[8],VARDATA(param8),VARSIZE(param8)-VARHDRSZ);
    memcpy(args[9],VARDATA(param9),VARSIZE(param9)-VARHDRSZ);
    memcpy(args[10],VARDATA(param10),VARSIZE(param10)-VARHDRSZ);


	args[0][VARSIZE(param0)-VARHDRSZ]='\0';
	args[1][VARSIZE(param1)-VARHDRSZ]='\0';
	args[2][VARSIZE(param2)-VARHDRSZ]='\0';
	args[3][VARSIZE(param3)-VARHDRSZ]='\0';
	args[4][VARSIZE(param4)-VARHDRSZ]='\0';
	args[5][VARSIZE(param5)-VARHDRSZ]='\0';
	args[6][VARSIZE(param6)-VARHDRSZ]='\0';
    args[7][VARSIZE(param7)-VARHDRSZ]='\0';
    args[8][VARSIZE(param8)-VARHDRSZ]='\0';
    args[9][VARSIZE(param9)-VARHDRSZ]='\0';
    args[10][VARSIZE(param10)-VARHDRSZ]='\0';
	args[11]=NULL;

	/*Fork em um novo processo*/
	if(!(child=vfork())){
		/*O processo filho entra aqui*/

		/*Substitui a imagem de memoria do processo*/
		syslog(LOG_INFO,"PostgreSQL executando o comando %s %s %s %s %s %s %s %s %s %s %s\n",args[0],args[1],args[2],args[3],args[4],args[5],args[6],args[7],args[8],args[9],args[10]);
		if(execve(args[0],args,environ)==-1){
			/*Nao foi possivel substituir a imagem do processo*/
			syslog(LOG_ERR,"N�o foi possivel executar %s %s %s %s %s %s %s %s %s %s %s\n",args[0],args[1],args[2],args[3],args[4],args[5],args[6],args[7], args[8], args[9], args[10]);
			exit(-1);
		}

	}else if(child!=-1){

		/*O pai em casos normais entra aqui*/
		if(wait(&status)!=child){
			/*Houve algum problema no processo filho*/
			syslog(LOG_ERR,"Pid retornado pelo processo filho nao corresponde ao esperado pelo pai. Mensagem da funcao exec do PostgreSQL\n");
			erro = -1;

		}else if(!WIFEXITED(status)){
			/*Processo filho nao terminou normalmente*/
			syslog(LOG_ERR,"Comando executado nao terminou normalmente. Mensagem da funcao exec do PostgreSQL\n");
			erro = -1;
		}

	}else{
		/*O pai caso nao tenha conseguido dar um fork entra aqui*/
		syslog(LOG_ERR,"Funcao exec do PostgreSQL nao conseguiu dar um fork\n");
		erro = -1;
	}


	pfree(args[0]);
	pfree(args[1]);
	pfree(args[2]);
	pfree(args[3]);
	pfree(args[4]);
	pfree(args[5]);
	pfree(args[6]);
    pfree(args[7]);
    pfree(args[8]);
    pfree(args[9]);
    pfree(args[10]);

	if(erro){
		/*Eh, tivemos problemas na execucao do processo filho. Mas
		fazer o que ne? Nem tudo na vida acontece como a gente quer.
		Observe as mensagens do syslog para ver o que pode ter ocorrido.*/
		PG_RETURN_INT32(-1);
	}

	/*Amem! O processo filho terminou normalmente. Vamos
	retornar o valor de retorno dele.*/

	PG_RETURN_INT32(WEXITSTATUS(status));
}

PG_FUNCTION_INFO_V1(exec12);

Datum exec12(PG_FUNCTION_ARGS){

	pid_t child; /*Pid do processo filho criado*/
	int status;  /*status de terminacao do processo filho*/

	/*Argumentos passados a funcao*/

	text	*param0 = PG_GETARG_TEXT_P(0);
	text	*param1 = PG_GETARG_TEXT_P(1);
	text    *param2 = PG_GETARG_TEXT_P(2);
	text	*param3 = PG_GETARG_TEXT_P(3);
	text	*param4	= PG_GETARG_TEXT_P(4);
	text	*param5 = PG_GETARG_TEXT_P(5);
	text    *param6 = PG_GETARG_TEXT_P(6);
    text    *param7 = PG_GETARG_TEXT_P(7);
    text    *param8 = PG_GETARG_TEXT_P(8);
    text    *param9 = PG_GETARG_TEXT_P(9);
    text    *param10 = PG_GETARG_TEXT_P(10);
    text    *param11 = PG_GETARG_TEXT_P(11);

	/*Variaveis das strings de comando*/


	char *args[13];

	erro = 0;

	/*+1 para o caracter de nulo*/

	args[0] = (char *) palloc(VARSIZE(param0)+1-VARHDRSZ);
	args[1] = (char *) palloc(VARSIZE(param1)+1-VARHDRSZ);
	args[2] = (char *) palloc(VARSIZE(param2)+1-VARHDRSZ);
	args[3] = (char *) palloc(VARSIZE(param3)+1-VARHDRSZ);
	args[4] = (char *) palloc(VARSIZE(param4)+1-VARHDRSZ);
	args[5] = (char *) palloc(VARSIZE(param5)+1-VARHDRSZ);
	args[6] = (char *) palloc(VARSIZE(param6)+1-VARHDRSZ);
    args[7] = (char *) palloc(VARSIZE(param7)+1-VARHDRSZ);
    args[8] = (char *) palloc(VARSIZE(param8)+1-VARHDRSZ);
    args[9] = (char *) palloc(VARSIZE(param9)+1-VARHDRSZ);
    args[10] = (char *) palloc(VARSIZE(param10)+1-VARHDRSZ);
    args[11] = (char *) palloc(VARSIZE(param11)+1-VARHDRSZ);


	memcpy(args[0],VARDATA(param0),VARSIZE(param0)-VARHDRSZ);
	memcpy(args[1],VARDATA(param1),VARSIZE(param1)-VARHDRSZ);
	memcpy(args[2],VARDATA(param2),VARSIZE(param2)-VARHDRSZ);
	memcpy(args[3],VARDATA(param3),VARSIZE(param3)-VARHDRSZ);
	memcpy(args[4],VARDATA(param4),VARSIZE(param4)-VARHDRSZ);
	memcpy(args[5],VARDATA(param5),VARSIZE(param5)-VARHDRSZ);
	memcpy(args[6],VARDATA(param6),VARSIZE(param6)-VARHDRSZ);
    memcpy(args[7],VARDATA(param7),VARSIZE(param7)-VARHDRSZ);
    memcpy(args[8],VARDATA(param8),VARSIZE(param8)-VARHDRSZ);
    memcpy(args[9],VARDATA(param9),VARSIZE(param9)-VARHDRSZ);
    memcpy(args[10],VARDATA(param10),VARSIZE(param10)-VARHDRSZ);
    memcpy(args[11],VARDATA(param11),VARSIZE(param11)-VARHDRSZ);


	args[0][VARSIZE(param0)-VARHDRSZ]='\0';
	args[1][VARSIZE(param1)-VARHDRSZ]='\0';
	args[2][VARSIZE(param2)-VARHDRSZ]='\0';
	args[3][VARSIZE(param3)-VARHDRSZ]='\0';
	args[4][VARSIZE(param4)-VARHDRSZ]='\0';
	args[5][VARSIZE(param5)-VARHDRSZ]='\0';
	args[6][VARSIZE(param6)-VARHDRSZ]='\0';
    args[7][VARSIZE(param7)-VARHDRSZ]='\0';
    args[8][VARSIZE(param8)-VARHDRSZ]='\0';
    args[9][VARSIZE(param9)-VARHDRSZ]='\0';
    args[10][VARSIZE(param10)-VARHDRSZ]='\0';
    args[11][VARSIZE(param11)-VARHDRSZ]='\0';
	args[12]=NULL;

	/*Fork em um novo processo*/
	if(!(child=vfork())){
		/*O processo filho entra aqui*/

		/*Substitui a imagem de memoria do processo*/
		syslog(LOG_INFO,"PostgreSQL executando o comando %s %s %s %s %s %s %s %s %s %s %s %s\n",args[0],args[1],args[2],args[3],args[4],args[5],args[6],args[7],args[8],args[9],args[10],args[11]);
		if(execve(args[0],args,environ)==-1){
			/*Nao foi possivel substituir a imagem do processo*/
			syslog(LOG_ERR,"N�o foi possivel executar %s %s %s %s %s %s %s %s %s %s %s %s\n",args[0],args[1],args[2],args[3],args[4],args[5],args[6],args[7], args[8], args[9], args[10],args[11]);
			exit(-1);
		}

	}else if(child!=-1){

		/*O pai em casos normais entra aqui*/
		if(wait(&status)!=child){
			/*Houve algum problema no processo filho*/
			syslog(LOG_ERR,"Pid retornado pelo processo filho nao corresponde ao esperado pelo pai. Mensagem da funcao exec do PostgreSQL\n");
			erro = -1;

		}else if(!WIFEXITED(status)){
			/*Processo filho nao terminou normalmente*/
			syslog(LOG_ERR,"Comando executado nao terminou normalmente. Mensagem da funcao exec do PostgreSQL\n");
			erro = -1;
		}

	}else{
		/*O pai caso nao tenha conseguido dar um fork entra aqui*/
		syslog(LOG_ERR,"Funcao exec do PostgreSQL nao conseguiu dar um fork\n");
		erro = -1;
	}


	pfree(args[0]);
	pfree(args[1]);
	pfree(args[2]);
	pfree(args[3]);
	pfree(args[4]);
	pfree(args[5]);
	pfree(args[6]);
    pfree(args[7]);
    pfree(args[8]);
    pfree(args[9]);
    pfree(args[10]);
    pfree(args[11]);

	if(erro){
		/*Eh, tivemos problemas na execucao do processo filho. Mas
		fazer o que ne? Nem tudo na vida acontece como a gente quer.
		Observe as mensagens do syslog para ver o que pode ter ocorrido.*/
		PG_RETURN_INT32(-1);
	}

	/*Amem! O processo filho terminou normalmente. Vamos
	retornar o valor de retorno dele.*/

	PG_RETURN_INT32(WEXITSTATUS(status));
}

PG_FUNCTION_INFO_V1(exec13);

Datum exec13(PG_FUNCTION_ARGS){

	pid_t child; /*Pid do processo filho criado*/
	int status;  /*status de terminacao do processo filho*/

	/*Argumentos passados a funcao*/

	text	*param0 = PG_GETARG_TEXT_P(0);
	text	*param1 = PG_GETARG_TEXT_P(1);
	text    *param2 = PG_GETARG_TEXT_P(2);
	text	*param3 = PG_GETARG_TEXT_P(3);
	text	*param4	= PG_GETARG_TEXT_P(4);
	text	*param5 = PG_GETARG_TEXT_P(5);
	text    *param6 = PG_GETARG_TEXT_P(6);
    text    *param7 = PG_GETARG_TEXT_P(7);
    text    *param8 = PG_GETARG_TEXT_P(8);
    text    *param9 = PG_GETARG_TEXT_P(9);
    text    *param10 = PG_GETARG_TEXT_P(10);
    text    *param11 = PG_GETARG_TEXT_P(11);
    text    *param12 = PG_GETARG_TEXT_P(12);

	/*Variaveis das strings de comando*/


	char *args[14];

	erro = 0;

	/*+1 para o caracter de nulo*/

	args[0] = (char *) palloc(VARSIZE(param0)+1-VARHDRSZ);
	args[1] = (char *) palloc(VARSIZE(param1)+1-VARHDRSZ);
	args[2] = (char *) palloc(VARSIZE(param2)+1-VARHDRSZ);
	args[3] = (char *) palloc(VARSIZE(param3)+1-VARHDRSZ);
	args[4] = (char *) palloc(VARSIZE(param4)+1-VARHDRSZ);
	args[5] = (char *) palloc(VARSIZE(param5)+1-VARHDRSZ);
	args[6] = (char *) palloc(VARSIZE(param6)+1-VARHDRSZ);
    args[7] = (char *) palloc(VARSIZE(param7)+1-VARHDRSZ);
    args[8] = (char *) palloc(VARSIZE(param8)+1-VARHDRSZ);
    args[9] = (char *) palloc(VARSIZE(param9)+1-VARHDRSZ);
    args[10] = (char *) palloc(VARSIZE(param10)+1-VARHDRSZ);
    args[11] = (char *) palloc(VARSIZE(param11)+1-VARHDRSZ);
    args[12] = (char *) palloc(VARSIZE(param12)+1-VARHDRSZ);


	memcpy(args[0],VARDATA(param0),VARSIZE(param0)-VARHDRSZ);
	memcpy(args[1],VARDATA(param1),VARSIZE(param1)-VARHDRSZ);
	memcpy(args[2],VARDATA(param2),VARSIZE(param2)-VARHDRSZ);
	memcpy(args[3],VARDATA(param3),VARSIZE(param3)-VARHDRSZ);
	memcpy(args[4],VARDATA(param4),VARSIZE(param4)-VARHDRSZ);
	memcpy(args[5],VARDATA(param5),VARSIZE(param5)-VARHDRSZ);
	memcpy(args[6],VARDATA(param6),VARSIZE(param6)-VARHDRSZ);
    memcpy(args[7],VARDATA(param7),VARSIZE(param7)-VARHDRSZ);
    memcpy(args[8],VARDATA(param8),VARSIZE(param8)-VARHDRSZ);
    memcpy(args[9],VARDATA(param9),VARSIZE(param9)-VARHDRSZ);
    memcpy(args[10],VARDATA(param10),VARSIZE(param10)-VARHDRSZ);
    memcpy(args[11],VARDATA(param11),VARSIZE(param11)-VARHDRSZ);
    memcpy(args[12],VARDATA(param12),VARSIZE(param12)-VARHDRSZ);


	args[0][VARSIZE(param0)-VARHDRSZ]='\0';
	args[1][VARSIZE(param1)-VARHDRSZ]='\0';
	args[2][VARSIZE(param2)-VARHDRSZ]='\0';
	args[3][VARSIZE(param3)-VARHDRSZ]='\0';
	args[4][VARSIZE(param4)-VARHDRSZ]='\0';
	args[5][VARSIZE(param5)-VARHDRSZ]='\0';
	args[6][VARSIZE(param6)-VARHDRSZ]='\0';
    args[7][VARSIZE(param7)-VARHDRSZ]='\0';
    args[8][VARSIZE(param8)-VARHDRSZ]='\0';
    args[9][VARSIZE(param9)-VARHDRSZ]='\0';
    args[10][VARSIZE(param10)-VARHDRSZ]='\0';
    args[11][VARSIZE(param11)-VARHDRSZ]='\0';
    args[12][VARSIZE(param12)-VARHDRSZ]='\0';
	args[13]=NULL;

	/*Fork em um novo processo*/
	if(!(child=vfork())){
		/*O processo filho entra aqui*/

		/*Substitui a imagem de memoria do processo*/
		syslog(LOG_INFO,"PostgreSQL executando o comando %s %s %s %s %s %s %s %s %s %s %s %s %s\n",args[0],args[1],args[2],args[3],args[4],args[5],args[6],args[7],args[8],args[9],args[10],args[11],args[12]);
		if(execve(args[0],args,environ)==-1){
			/*Nao foi possivel substituir a imagem do processo*/
			syslog(LOG_ERR,"N�o foi possivel executar %s %s %s %s %s %s %s %s %s %s %s %s %s\n",args[0],args[1],args[2],args[3],args[4],args[5],args[6],args[7], args[8], args[9], args[10],args[11],args[12]);
			exit(-1);
		}

	}else if(child!=-1){

		/*O pai em casos normais entra aqui*/
		if(wait(&status)!=child){
			/*Houve algum problema no processo filho*/
			syslog(LOG_ERR,"Pid retornado pelo processo filho nao corresponde ao esperado pelo pai. Mensagem da funcao exec do PostgreSQL\n");
			erro = -1;

		}else if(!WIFEXITED(status)){
			/*Processo filho nao terminou normalmente*/
			syslog(LOG_ERR,"Comando executado nao terminou normalmente. Mensagem da funcao exec do PostgreSQL\n");
			erro = -1;
		}

	}else{
		/*O pai caso nao tenha conseguido dar um fork entra aqui*/
		syslog(LOG_ERR,"Funcao exec do PostgreSQL nao conseguiu dar um fork\n");
		erro = -1;
	}


	pfree(args[0]);
	pfree(args[1]);
	pfree(args[2]);
	pfree(args[3]);
	pfree(args[4]);
	pfree(args[5]);
	pfree(args[6]);
    pfree(args[7]);
    pfree(args[8]);
    pfree(args[9]);
    pfree(args[10]);
    pfree(args[11]);
    pfree(args[12]);

	if(erro){
		/*Eh, tivemos problemas na execucao do processo filho. Mas
		fazer o que ne? Nem tudo na vida acontece como a gente quer.
		Observe as mensagens do syslog para ver o que pode ter ocorrido.*/
		PG_RETURN_INT32(-1);
	}

	/*Amem! O processo filho terminou normalmente. Vamos
	retornar o valor de retorno dele.*/

	PG_RETURN_INT32(WEXITSTATUS(status));
}
