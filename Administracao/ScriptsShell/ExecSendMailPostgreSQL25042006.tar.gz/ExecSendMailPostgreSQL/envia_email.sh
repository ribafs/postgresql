#!/bin/sh
#Autor: Otacilio de Araujo Ramos Neto 23/11/2005 'as 11:14h.
#Este script envia o arquivo de proposta propriamente dito para os destinat�rios.

#Parametros 
# $1-> From
# $2-> To
# $3-> Subject
# $4-> Texto
# $5-> Anexo

for i in $2; do 
	
	#Primeiro vamos criar o arquivo
	echo "From: <$1>" > /var/tmp/mensagem
        echo "To: <$i>" >> /var/tmp/mensagem
	echo "Subject: $3">>/var/tmp/mensagem
	echo "$4" >>/var/tmp/mensagem

	#echo "$1" >/var/tmp/arquivo
	for j in $5; do
		#Modificar para so aparecer o nome do arquivo, sem o caminho
		uuencode "$j" "$j" >>/var/tmp/mensagem
	done

	sendmail -t -f$1 < /var/tmp/mensagem
	
done

rm -f /var/tmp/mensagem

exit 0
