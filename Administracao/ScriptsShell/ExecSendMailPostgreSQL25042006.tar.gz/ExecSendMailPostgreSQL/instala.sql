CREATE OR REPLACE FUNCTION exec(text) RETURNS integer AS 'execPostgreSQL.so','exec1' LANGUAGE C STRICT;
REVOKE EXECUTE ON FUNCTION exec(text) FROM PUBLIC;

CREATE OR REPLACE FUNCTION exec(text,text) RETURNS integer AS 'execPostgreSQL.so','exec2' LANGUAGE C STRICT;
REVOKE EXECUTE ON FUNCTION exec(text,text) FROM PUBLIC;

CREATE OR REPLACE FUNCTION exec(text,text,text) RETURNS integer AS 'execPostgreSQL.so','exec3' LANGUAGE C STRICT;
REVOKE EXECUTE ON FUNCTION exec(text,text,text) FROM PUBLIC;

CREATE OR REPLACE FUNCTION exec(text,text,text,text) RETURNS integer AS 'execPostgreSQL.so','exec4' LANGUAGE C STRICT;
REVOKE EXECUTE ON FUNCTION exec(text,text,text,text) FROM PUBLIC;

CREATE OR REPLACE FUNCTION exec(text,text,text,text,text) RETURNS integer AS 'execPostgreSQL.so','exec5' LANGUAGE C STRICT;
REVOKE EXECUTE ON FUNCTION exec(text,text,text,text,text) FROM PUBLIC;

CREATE OR REPLACE FUNCTION exec(text,text,text,text,text,text) RETURNS integer AS 'execPostgreSQL.so','exec6' LANGUAGE C STRICT;
REVOKE EXECUTE ON FUNCTION exec(text,text,text,text,text,text) FROM PUBLIC;

CREATE OR REPLACE FUNCTION exec(text,text,text,text,text,text,text) RETURNS integer AS 'execPostgreSQL.so','exec7' LANGUAGE C STRICT;
REVOKE EXECUTE ON FUNCTION exec(text,text,text,text,text,text,text) FROM PUBLIC;

CREATE OR REPLACE FUNCTION exec(text,text,text,text,text,text,text,text) RETURNS integer AS 'execPostgreSQL.so','exec8' LANGUAGE C STRICT;
REVOKE EXECUTE ON FUNCTION exec(text,text,text,text,text,text,text,text) FROM PUBLIC;

CREATE OR REPLACE FUNCTION exec(text,text,text,text,text,text,text,text,text) RETURNS integer AS 'execPostgreSQL.so','exec9' LANGUAGE C STRICT;
REVOKE EXECUTE ON FUNCTION exec(text,text,text,text,text,text,text,text,text) FROM PUBLIC;

CREATE OR REPLACE FUNCTION exec(text,text,text,text,text,text,text,text,text,text) RETURNS integer AS 'execPostgreSQL.so','exec10' LANGUAGE C STRICT;
REVOKE EXECUTE ON FUNCTION exec(text,text,text,text,text,text,text,text,text,text) FROM PUBLIC;

CREATE OR REPLACE FUNCTION exec(text,text,text,text,text,text,text,text,text,text,text) RETURNS integer AS 'execPostgreSQL.so','exec11' LANGUAGE C STRICT;
REVOKE EXECUTE ON FUNCTION exec(text,text,text,text,text,text,text,text,text,text,text) FROM PUBLIC;

CREATE OR REPLACE FUNCTION exec(text,text,text,text,text,text,text,text,text,text,text,text) RETURNS integer AS 'execPostgreSQL.so','exec12' LANGUAGE C STRICT;
REVOKE EXECUTE ON FUNCTION exec(text,text,text,text,text,text,text,text,text,text,text,text) FROM PUBLIC;

CREATE OR REPLACE FUNCTION exec(text,text,text,text,text,text,text,text,text,text,text,text,text) RETURNS integer AS 'execPostgreSQL.so','exec13' LANGUAGE C STRICT;
REVOKE EXECUTE ON FUNCTION exec(text,text,text,text,text,text,text,text,text,text,text,text,text) FROM PUBLIC;

CREATE OR REPLACE FUNCTION envia_email(text,text,text,text,text) RETURNS int4 AS $BODY$ BEGIN return exec('/usr/local/lib/postgresql/envia_email.sh',$1,$2,$3,$4,$5); END; $BODY$ LANGUAGE 'plpgsql' VOLATILE;
REVOKE EXECUTE ON FUNCTION envia_email(text,text,text,text,text) FROM PUBLIC;
