<?php
// exatamente o tempo que gastei com 64kbps sem testar com o preg_match_all
set_time_limit(1530); // bem alto pois demorar� bastante // 1530s=25e1/2min

//$cCod = $_GET['c'];
//$cQnt = $_GET['n'] ? $_GET['n'] : 0 ;

// http://www.datingplace.com/jsp/cities_reg.jsp?state_id=1&country_id=1

//function get_states($cQnt){

require("config.inc.php");

$pC = @file($dbDir."countries_codes.db"); // 50 countries, 50 codes

$erro=0;

for($cQnt=0; $cQnt<count($pC); $cQnt++){	

//	global $cQnt;
	
	//require("config.inc.php");
/*
	$pC = file($dbDir."countries_codes.db");
	$cLin = array_search($pC[$cQnt],$pC);
			
	if($cLin!=0 && empty($cLin))
		exit("Country code doesn�t exists");
*/	
	$pN = @file($dbDir."countries.db");
	$pNm = trim($pN[$cQnt]);
		
	$sCd = @file($dbDir.$pNm."/".$pNm."_codes.db");
	$sNm = @file($dbDir.$pNm."/".$pNm.".db");
		
	// some countries doesn�t have fixed states, so we get they�re cities anyway
	if(!$sCd || count($sCd)==0) 
		$sCd = array(0);
	if(!$sNm || count($sNm)==0)
		$sNm = array("empty");
		
	for($i=0; $i<count($sCd); $i++){
		
		$cT = @file_get_contents("http://www.datingplace.com/jsp/cities_reg.jsp?state_id=".trim($sCd[$i])."&country_id=".trim($pC[$cQnt]));
	
		if($cT=="")
			$erro=1;
							
		preg_match("/<select.*?>(.+)<\/select>/is",$cT,$matches);
		
		if(!is_dir($dbDir.trim($pNm)."/".trim($sNm[$i])."/"))
			if(!@mkdir($dbDir.trim($pNm)."/".trim($sNm[$i])."/",0644))
				$erro=1;
		// Getting they�re names
		/* OLD CODE
			   // removing also the <script> that they made the favor to put inside select tags
			   // no problem. That is not obstacle for us (until now, at least).
		$rem = array("'<option.*?>'is","'<\/option>'is","'(<script.*?>.+<\/script>)'is");
		$rep = array("","","");
		$esT = preg_replace($rem,$rep,$matches[1]);
		$esT = ereg_replace("  ","", $esT );
		$esT = ereg_replace("\r\n",",",$esT);
		$esT = ereg_replace(",,",",",$esT);
				
		$res = explode(",",$esT);
		array_pop($res); // empty array pointer
		array_shift($res); // empty array
		array_shift($res); // This is a Select a state option. We remove it
		$res = implode("\r\n",$res);
		/OLD CODE */
		// NEW CODE
		@preg_match_all("'<option[^>]*?>([^>]*?)<\/option>'is",$matches[1],$res);
		$res = @implode("\r\n",$res[1]);
		$res = @ereg_replace("  ","",$res);
		if($res=="")
			$erro=1;
		// /NEW CODE		
		
		$fp = @fopen($dbDir.trim($pNm)."/".trim($sNm[$i])."/".trim($sNm[$i]).".db","w");
		if($fp)
			if(!@fwrite($fp,$res))
				$erro=1;
			else
				$erro=0;
		else
			$erro=1;
		@fclose($fp);
		
		// Then, we get they�re codes
		/* OLD CODE
			   // removing [a-zA-Z] we would obtain code Country in each line // [a-zA-Z���������������\(\)\'\.-]
		$rem2 = array("'<script[^>]*?>.*?</script>'si","'<option value='is","'>'is","'<\/option'is","'[a-zA-Z���������������\(\)\'\.-]'is");
		$rep2 = array("","","","","");
		$nmS = preg_replace($rem2,$rep2,$matches[1]);
		$nmS = ereg_replace(" ","", $nmS ); // removing all spaces instead of "  " (double spaces)
											// if displaying code and country just remove the double
		$nmS = ereg_replace("\r\n",",",$nmS);
		$nmS = ereg_replace(",,",",",$nmS);
		
		$res = explode(",",$nmS);
		array_pop($res);
		array_shift($res); // the first key has the code of the Select a state. This removes it
		array_shift($res);
		$res = implode("\r\n",$res);
		/OLD CODE */
		// NEW CODE
		@preg_match_all("'<option value=([0-9]+ )[^>]*?>'is",$matches[1],$res);
		$res = @implode("\r\n",$res[1]);
		$res = @ereg_replace(" ","",$res);
		if($res=="")
			$erro=1;
		// /NEW CODE
		
		$fp = @fopen($dbDir.trim($pNm)."/".trim($sNm[$i])."/".trim($sNm[$i])."_codes.db","w");
		if($fp)
			if(!@fwrite($fp,$res))
				$erro=1;
			else
				$erro=0;
		else
			$erro=1;
		@fclose($fp);
	
	}
	/*
	++$cQnt;	
	if($end)
		echo "<script>window.open('$PHP_SELF?n=$cQnt','_top')</script>";
	*/
}
/*
// here we do some while to get all the states just reloading the page.
// we send and counter to see how many we got and form which country we need to cath the cities

require("config.inc.php");

$pC = file($dbDir."countries_codes.db");

if( $cQnt < count($pC) )
	get_states($cQnt);




*/

if($erro)
	echo "Error while creating the cities db";
else
	echo "Cities db created with sucess";
?>