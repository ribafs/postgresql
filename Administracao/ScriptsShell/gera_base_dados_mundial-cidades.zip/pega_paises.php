<?php

require "config.inc.php";

// http://www.datingplace.com/servlet/NewRegistration
$erro=0;
$content = @file_get_contents("http://www.datingplace.com/servlet/NewRegistration");

if($content=="")
	$erro=1;

@preg_match("/<select size=1 name=\"country\".*?>(.+)<\/select>/is",$content,$matches);

if(!is_dir($dbDir))
	if(!@mkdir($dbDir,0644))
		$erro.=1;
// So first, lets get the countries

	/* INSTEAD OFF ALL THOS IS TREATMENT WE CAN DO A SIMPLE preg_match 
	$rem = array("'<option.*?>'is","'<\/option>'is");
	$rep = array("","");
	$ctS = preg_replace($rem,$rep,$matches[1]);
	$ctS = ereg_replace("  ","", $ctS );
	$ctS = ereg_replace("\r\n",",",$ctS);
	$ctS = ereg_replace(",,",",",$ctS);
	
	$exp = explode(",",$ctS);
	array_pop($exp);
	array_shift($exp);
	$res = implode("\r\n",$res);
	*/
	// WE DOO THIS
	// instead of all the stuff above, we do another match, remove double spaces 
	// and change double breaklines for singles
	
//$exp = ereg_replace("  ","",$exp[1]);
//$exp = ereg_replace("\r\n\r\n","\r\n",$exp)
@preg_match_all("'<option[^>]*?>([^>]*?)<\/option>'is",$matches[1],$exp);;
$exp = @implode("\r\n",$exp[1]);
$exp = @ereg_replace("  ","",$exp);

if($exp=="")
	$erro=1;

$fp = @fopen($dbDir."countries.db","w");
if($fp)
	if(!@fwrite($fp,$exp))
		$erro=1;
	else
		$erro=0; // I put this line because of false error messages
else
	$erro=1;
@fclose($fp);


// Then, we get they�re code
	/* INSTEAD OF THIS
		   // removing [a-zA-Z] we would obtain code Country in each line
	$rem = array("'<option value='is","'>'is","'<\/option'is","'[a-zA-Z]'is");
	$rep = array("","","","");
	$nmS = preg_replace($rem,$rep,$matches[1]);
	$nmS = ereg_replace(" ","", $nmS ); // removing all spaces instead of "  " (double spaces)
										// if displaying code and country just remove the double
	$nmS = ereg_replace("\r\n",",",$nmS);
	$nmS = ereg_replace(",,",",",$nmS);
	
	$res = explode(",",$nmS);
	array_pop($res);
	array_shift($res);
	$res = implode("\r\n",$res);
	*/
	// WE DO THIS

@preg_match_all("'<option value=([0-9]+ )[^>]*?>'is",$matches[1],$res);
$res = @implode("\r\n",$res[1]);
$res = @ereg_replace(" ","",$res);

if($res=="")
	$erro=1;

$fp = @fopen($dbDir."countries_codes.db","w");
if($fp)
	if(!@fwrite($fp,$res))
		$erro=1;
	else
		$erro=0;  // I put this line because of false error messages
else
	$erro=1;
@fclose($fp);


// Finally, we search for errors during the program

if($erro)
	echo "Error while creating the countries db<br>"
	   . "Do you have permission to write in $dbDir ?";
else
	echo "Countries db created with sucess";

?>