<?php
$dbDir = "db/";
?>