<?php
// no need of setting time limit. It get all of them in 10s in a 64kb broadband
// but we set it to 2minutes because db can be updated. so we reduce error risks
set_time_limit(120);

require("config.inc.php");

$cD = @file($dbDir."countries.db");
$c = @file($dbDir."countries_codes.db");

$erro=0;
if(count($cD)==0 || count($c)==0)
	$erro.=1;

for($i=0;$i<count($c);$i++){
/* using fsockopen
	$fp = fsockopen("www.datingplace.com",80,$errno);
	if ($fp){
		fputs($fp,"GET /jsp/states_reg.jsp?country_id=".trim($c[$i])." HTTP/1.0\r\nHost: www.datingplace.com\r\n\r\n");
		while (!feof($fp))
			$cT .= fgets ($fp,128);
*/	
	// the trim here is very important. no spaces are allowed in urls
	$cT = @file_get_contents("http://www.datingplace.com/jsp/states_reg.jsp?country_id=".trim($c[$i]));
	
		
	if($cT=="")
		$erro.=1;
			
	@preg_match("/<select.*?>(.+)<\/select>/is",$cT,$matches);
	
	// Getting they�re names
	/*
	$rem = array("'<option.*?>'is","'<\/option>'is");
	$rep = array("","");
	$esT = preg_replace($rem,$rep,$matches[1]);
	$esT = ereg_replace("  ","", $esT );
	$esT = ereg_replace("\r\n",",",$esT);
	$esT = ereg_replace(",,",",",$esT);
	
	$res = explode(",",$esT);
	array_pop($res); // empty array pointer
	array_shift($res); // empty array
	array_shift($res); // This is a Select a state option. We remove it
	$res = implode("\r\n",$res);
	*/
	@preg_match_all("'<option[^>]*?>([^>]*?)<\/option>'is",$matches[1],$res);
	@array_shift($res[1]); // This is a Select a state option. We remove it
	$res = @implode("\r\n",$res[1]);
	$res = @ereg_replace("  ","",$res);
	
	if(!is_dir($dbDir.trim($cD[$i])."/"))
		if(!@mkdir($dbDir.trim($cD[$i])."/",0644))
			$erro.=1;
		else
			$erro.=0;
	
	$fp = @fopen($dbDir.trim($cD[$i])."/".trim($cD[$i]).".db","w");
	if($fp)
		if($res!="" && !@fwrite($fp,$res))
			$erro.=1;
		else
			$erro.=0;
	else
		$erro.=1;
	fclose($fp);
	
	// Then, we get they�re codes
	/*
		   // removing [a-zA-Z] we would obtain code Country in each line
	$rem = array("'<option value='is","'>'is","'<\/option'is","'[a-zA-Z]'is");
	$rep = array("","","","");
	$nmS = preg_replace($rem,$rep,$matches[1]);
	$nmS = ereg_replace(" ","", $nmS ); // removing all spaces instead of "  " (double spaces)
										// if displaying code and country just remove the double
	$nmS = ereg_replace("\r\n",",",$nmS);
	$nmS = ereg_replace(",,",",",$nmS);
	
	$res = explode(",",$nmS);
	array_pop($res);
	array_shift($res); // the first key has the code of the Select a state. This removes it
	array_shift($res);
	$res = implode("\r\n",$res);
	*/	
	@preg_match_all("'<option value=([0-9]+ )[^>]*?>'is",$matches[1],$res);
	// we don�t do the array_shift againa because we already did it up in the code
	//array_shift($res[1]); // the first key has the code of the Select a state. This removes it
	$res = @implode("\r\n",$res[1]);
	$res = @ereg_replace(" ","",$res);
			
	$fp = @fopen($dbDir.trim($cD[$i])."/".trim($cD[$i])."_codes.db","w");
	if($fp)
		if($res!="" && !@fwrite($fp,$res))
			$erro.=1;
		else
			$erro.=0;
	else
		$erro.=1;
	@fclose($fp);
	
}

if($erro && $erro!=0)
	echo "$erro Error(s) while creating the states db";		 
else
	echo "States db created with sucess";
echo "<br>Don�t worry, some countries like Angola and Argentina the states will be empty";

?>